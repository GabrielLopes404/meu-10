import { motion } from "framer-motion";
import { Check, ArrowRight, Sparkles, TrendingUp, Palette, Globe, Zap } from "lucide-react";

const WHATSAPP_NUMBER = "5561991475054";

const createWhatsAppLink = (message: string) => {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
};

export function Hero() {
  const services = [
    {
      icon: Palette,
      title: "Design Gráfico",
      description: "Identidade visual que marca presença",
      color: "from-pink-500 to-rose-500",
      bgColor: "bg-pink-500/10",
      borderColor: "border-pink-500/20",
    },
    {
      icon: Globe,
      title: "Sites & Apps",
      description: "Desenvolvimento web profissional",
      color: "from-blue-500 to-cyan-500",
      bgColor: "bg-blue-500/10",
      borderColor: "border-blue-500/20",
    },
    {
      icon: TrendingUp,
      title: "Gestão de Tráfego",
      description: "Anúncios que geram resultados",
      color: "from-green-500 to-emerald-500",
      bgColor: "bg-green-500/10",
      borderColor: "border-green-500/20",
    },
  ];

  const stats = [
    { value: "350+", label: "Projetos Entregues" },
    { value: "98%", label: "Clientes Satisfeitos" },
    { value: "24h", label: "Suporte Dedicado" },
  ];

  const benefits = [
    "Atendimento personalizado para seu negócio",
    "Entrega rápida sem perder qualidade",
    "Suporte completo do início ao fim"
  ];

  return (
    <section className="relative min-h-screen flex items-center bg-gradient-to-br from-[#0a0a0a] via-[#1a0a1a] to-[#0a0a0a] overflow-hidden" data-testid="section-hero">
      {/* Advanced Background Effects */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff03_1px,transparent_1px),linear-gradient(to_bottom,#ffffff03_1px,transparent_1px)] bg-[size:4rem_4rem]" />
      
      {/* Animated Gradient Orbs */}
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.15, 0.3, 0.15],
          x: [0, 50, 0],
          y: [0, -30, 0],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute top-0 right-0 w-[800px] h-[800px] bg-primary/20 rounded-full blur-[150px]"
      />
      <motion.div
        animate={{
          scale: [1, 1.3, 1],
          opacity: [0.1, 0.25, 0.1],
          x: [0, -30, 0],
          y: [0, 50, 0],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 3,
        }}
        className="absolute bottom-0 left-0 w-[700px] h-[700px] bg-blue-500/15 rounded-full blur-[150px]"
      />

      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 lg:py-32">
        {/* Top Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex justify-center mb-8"
        >
          <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-primary/10 via-blue-500/10 to-green-500/10 border border-primary/30 backdrop-blur-md">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-bold bg-gradient-to-r from-primary via-blue-400 to-green-400 bg-clip-text text-transparent">
              Agência Digital Completa • Design • Sites • Tráfego
            </span>
          </div>
        </motion.div>

        {/* Main Content */}
        <div className="text-center space-y-8 mb-16">
          {/* Hero Title */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-6"
          >
            <h1 className="font-display font-black text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-tight max-w-5xl mx-auto" data-testid="text-hero-title">
              <span className="text-white">Transforme seu negócio com </span>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-pink-400 to-primary animate-gradient">
                soluções digitais completas
              </span>
            </h1>
            <p className="text-base sm:text-lg md:text-xl text-white/70 leading-relaxed max-w-3xl mx-auto px-4" data-testid="text-hero-subtitle">
              Da identidade visual ao tráfego pago: oferecemos design gráfico profissional, desenvolvimento de sites modernos e gestão de anúncios que realmente convertem. Tudo em um só lugar.
            </p>
          </motion.div>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            <motion.a
              href={createWhatsAppLink("Olá! Quero transformar meu negócio com soluções digitais completas. Gostaria de solicitar um orçamento!")}
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              data-testid="button-cta-hero"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-primary via-pink-500 to-primary bg-[length:200%_auto] hover:bg-right text-white font-bold text-base rounded-xl shadow-[0_0_50px_rgba(236,72,153,0.5)] hover:shadow-[0_0_80px_rgba(236,72,153,0.8)] transition-all duration-500 relative overflow-hidden group"
            >
              <span className="relative z-10">Quero Crescer Meu Negócio</span>
              <ArrowRight className="w-5 h-5 relative z-10 group-hover:translate-x-1 transition-transform" />
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/25 to-white/0"
                animate={{ x: ["-100%", "100%"] }}
                transition={{ duration: 2.5, repeat: Infinity, ease: "linear", repeatDelay: 1 }}
              />
            </motion.a>
            
            <motion.a
              href={createWhatsAppLink("Olá! Gostaria de conhecer melhor os serviços da agência e ver cases de sucesso.")}
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white/5 hover:bg-white/10 text-white font-bold text-base rounded-xl border-2 border-white/20 hover:border-primary/50 backdrop-blur-sm transition-all duration-300"
            >
              Conhecer a Agência
            </motion.a>
          </motion.div>

          {/* Benefits Checklist */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 sm:gap-8 justify-center items-center pt-4"
          >
            {benefits.map((benefit, index) => (
              <div key={index} className="flex items-center gap-2">
                <div className="flex-shrink-0 w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center">
                  <Check className="w-3 h-3 text-primary" />
                </div>
                <span className="text-sm text-white/80 font-medium">{benefit}</span>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Services Cards */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-16"
        >
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.9 + index * 0.1 }}
                whileHover={{ y: -8, scale: 1.02 }}
                className={`relative group p-6 rounded-2xl bg-gradient-to-br from-white/5 to-white/[0.02] border ${service.borderColor} backdrop-blur-sm hover:border-opacity-50 transition-all duration-300`}
              >
                {/* Number Badge */}
                <div className="absolute top-4 right-4 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center border border-white/10">
                  <span className="text-xs font-bold text-white/50">0{index + 1}</span>
                </div>

                {/* Icon */}
                <div className={`w-14 h-14 rounded-xl ${service.bgColor} border ${service.borderColor} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className={`w-7 h-7 bg-gradient-to-br ${service.color} bg-clip-text text-transparent`} style={{ WebkitTextFillColor: 'transparent' }} />
                </div>

                {/* Content */}
                <h3 className="font-display font-bold text-xl text-white mb-2">
                  {service.title}
                </h3>
                <p className="text-sm text-white/60 leading-relaxed">
                  {service.description}
                </p>

                {/* Hover Glow */}
                <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${service.color} opacity-0 group-hover:opacity-10 blur-xl transition-opacity duration-300`} />
              </motion.div>
            );
          })}
        </motion.div>

        {/* Stats Bar */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1.2 }}
          className="relative rounded-2xl bg-gradient-to-r from-white/[0.07] via-white/[0.05] to-white/[0.07] border border-white/10 backdrop-blur-md p-6 sm:p-8 overflow-hidden"
        >
          {/* Background Glow */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-full bg-primary/10 blur-[100px]" />
          
          <div className="relative z-10 grid grid-cols-1 sm:grid-cols-3 gap-8 sm:gap-4">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.6, delay: 1.4 + index * 0.1, type: "spring" }}
                  className="font-display font-black text-4xl sm:text-5xl bg-gradient-to-r from-primary via-pink-400 to-primary bg-clip-text text-transparent mb-2"
                >
                  {stat.value}
                </motion.div>
                <div className="text-sm font-semibold text-white/60">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Bottom Fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#0a0a0a] to-transparent pointer-events-none" />
    </section>
  );
}
