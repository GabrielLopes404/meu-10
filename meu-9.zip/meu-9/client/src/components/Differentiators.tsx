import { Eye, Sparkles, Box, Video, Zap, Palette } from "lucide-react";
import { motion } from "framer-motion";

export function Differentiators() {
  const services = [
    {
      icon: Eye,
      title: "Identidade Visual",
      description: "Identidade visual forte, moderna e memorável pra sua marca se destacar.",
      benefits: [
        "Logo profissional e única",
        "Manual de marca completo",
        "Aplicações em diversos formatos"
      ],
      gradient: "from-pink-600 to-rose-600",
      glow: "rgba(236,72,153,0.5)"
    },
    {
      icon: Sparkles,
      title: "Peças para Mídias",
      description: "Criações impactantes que atraem, comunicam e vendem mais.",
      benefits: [
        "Posts para redes sociais",
        "Stories animados",
        "Banners e anúncios"
      ],
      gradient: "from-purple-600 to-pink-600",
      glow: "rgba(168,85,247,0.5)"
    },
    {
      icon: Box,
      title: "Modelagem 3D",
      description: "Modelagens únicas e originais para dar vida à sua ideia ou marca.",
      benefits: [
        "Produtos em 3D realistas",
        "Personagens exclusivos",
        "Cenários e ambientes"
      ],
      gradient: "from-blue-600 to-purple-600",
      glow: "rgba(59,130,246,0.5)"
    },
    {
      icon: Video,
      title: "Pacote Audiovisual",
      description: "Designs completos, bonitos e funcionais prontos para usar em projetos digitais.",
      benefits: [
        "Motion graphics profissionais",
        "Vídeos institucionais",
        "Edição e pós-produção"
      ],
      gradient: "from-cyan-600 to-blue-600",
      glow: "rgba(6,182,212,0.5)"
    },
    {
      icon: Zap,
      title: "Edições para Internet",
      description: "Tudo que sua marca precisa em um só lugar: qualidade, agilidade e preço justo.",
      benefits: [
        "Edição de vídeos curtos",
        "Thumbnails atrativas",
        "Conteúdo otimizado"
      ],
      gradient: "from-emerald-600 to-cyan-600",
      glow: "rgba(16,185,129,0.5)"
    },
    {
      icon: Palette,
      title: "Design Personalizado",
      description: "Projetos sob medida que traduzem perfeitamente a essência da sua marca.",
      benefits: [
        "Consultoria de branding",
        "Direção de arte",
        "Conceito criativo exclusivo"
      ],
      gradient: "from-orange-600 to-pink-600",
      glow: "rgba(249,115,22,0.5)"
    },
  ];

  return (
    <section className="py-16 md:py-24 lg:py-32 bg-gradient-to-b from-[#050505] via-[#0a0012] to-[#050505] relative overflow-hidden" data-testid="section-differentiators">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff03_1px,transparent_1px),linear-gradient(to_bottom,#ffffff03_1px,transparent_1px)] bg-[size:4rem_4rem]"></div>
      <motion.div
        animate={{
          opacity: [0.05, 0.15, 0.05],
          scale: [1, 1.1, 1]
        }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-0 right-0 w-96 h-96 md:w-[600px] md:h-[600px] bg-primary/10 rounded-full blur-[120px]"
      />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12 md:mb-16 space-y-4"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/20 border border-primary/40 mb-4 shadow-[0_0_20px_rgba(236,72,153,0.3)]">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary uppercase tracking-wider">Expertise</span>
          </div>
          <h2 className="font-display font-bold text-3xl sm:text-4xl md:text-5xl lg:text-6xl uppercase tracking-tight text-white">
            O que eu <span className="text-primary">faço</span>
          </h2>
          <p className="text-base md:text-lg text-white/60 max-w-2xl mx-auto">
            Serviços completos de design e criação digital
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 lg:gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{
                  duration: 0.6,
                  delay: index * 0.1,
                  ease: [0.22, 1, 0.36, 1]
                }}
                whileHover={{ y: -8, scale: 1.02 }}
                className="group relative rounded-2xl bg-gradient-to-br from-[#1a1a1a]/80 via-[#0f0f0f]/80 to-[#0a0a0a]/80 backdrop-blur-sm border border-white/10 hover:border-white/30 p-6 md:p-8 transition-all duration-500 overflow-hidden"
                style={{
                  boxShadow: `0 0 0 rgba(0,0,0,0)`,
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.boxShadow = `0 0 60px ${service.glow}`;
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.boxShadow = `0 0 0 rgba(0,0,0,0)`;
                }}
                data-testid={`card-differentiator-${index}`}
              >
                <motion.div
                  className="absolute top-0 right-0 w-32 h-32 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  style={{ background: service.glow }}
                />
                
                <div className="relative z-10 space-y-4">
                  <motion.div
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    transition={{ type: "spring", stiffness: 400 }}
                    className="w-fit"
                  >
                    <div className={`w-14 h-14 md:w-16 md:h-16 rounded-xl bg-gradient-to-br ${service.gradient} flex items-center justify-center shadow-2xl`}
                      style={{ boxShadow: `0 10px 40px ${service.glow}` }}
                    >
                      <Icon className="w-7 h-7 md:w-8 md:h-8 text-white drop-shadow-lg" />
                    </div>
                  </motion.div>

                  <div className="space-y-2">
                    <h3 className="font-display font-bold text-xl md:text-2xl text-white group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-white group-hover:via-primary group-hover:to-white transition-all duration-300" data-testid={`text-differentiator-title-${index}`}>
                      {service.title}
                    </h3>
                    <p className="text-sm md:text-base text-white/70 leading-relaxed" data-testid={`text-differentiator-desc-${index}`}>
                      {service.description}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-white/10 space-y-2">
                    {service.benefits.map((benefit, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, x: -10 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: index * 0.1 + i * 0.05 }}
                        className="flex items-center gap-2 text-xs md:text-sm text-white/60"
                      >
                        <div className={`w-1.5 h-1.5 rounded-full bg-gradient-to-r ${service.gradient} flex-shrink-0`}></div>
                        <span>{benefit}</span>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
